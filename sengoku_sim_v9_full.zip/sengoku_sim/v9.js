/* =========================================================
   戦国シミュレーション v9 本格シミュレーション拡張
   v7/v8の既存データ構造を壊さず、経済・AI・戦闘・城郭・補給・外交・諜報・保存を統合。
   ========================================================= */
(() => {
  'use strict';
  const S = window.state;
  if (!S) return;
  S.version = 'v9';
  S.date = S.date || {year:1560, season:0};
  S.ai = S.ai || {};
  S.economy = S.economy || {};
  S.log = S.log || [];
  S.intelligence = S.intelligence || {};
  S.diplomacy = S.diplomacy || {};
  S.supply = S.supply || {};
  S.castleState = S.castleState || {};
  S.weather = S.weather || '晴';

  const SEASONS=['春','夏','秋','冬'];
  const TERRAIN={
    '山地':{move:1.45,def:1.18,attack:.86},'平野':{move:.9,def:1,attack:1.05},
    '丘陵':{move:1.12,def:1.08,attack:.94},'河川':{move:1.25,def:1.15,attack:.78},
    '海岸':{move:.95,def:.98,attack:1},'湿地':{move:1.35,def:1.12,attack:.82}
  };
  const PERSONALITIES=['拡張型','防衛型','内政型','外交型','好戦型','慎重型'];

  // ---------- 基礎データ ----------
  S.provinces.forEach(p=>{
    p.terrainType = p.terrainType || inferTerrain(p.name);
    p.infrastructure = p.infrastructure ?? 40;
    p.floodControl = p.floodControl ?? 35;
    p.commerce = p.commerce ?? 30;
    p.development = p.development ?? Math.min(90, Math.round(p.koku*.75));
    p.loyalty = p.loyalty ?? 70;
    p.unrest = p.unrest ?? 0;
    p.population = p.pop ?? p.population ?? p.koku*3500;
    p.foodStock = p.food ?? p.foodStock ?? p.koku*550;
    p.goldStock = p.gold ?? p.goldStock ?? p.koku*170;
    p.mobilization = p.mobilization ?? .11;
    p.taxRate = p.taxRate ?? .28;
    p.garrison = p.garrison ?? Math.round(p.koku*90);
  });
  S.armies.forEach(a=>initArmy(a));
  S.retainers.forEach((r,i)=>{
    const [name,role,lead,war,dom,fin,dip]=r;
    S.ai.officers = S.ai.officers || {};
    S.ai.officers[name] = S.ai.officers[name] || {name,role,leadership:lead,martial:war,domestic:dom,finance:fin,diplomacy:dip,loyalty:70,exp:50};
  });
  ['黒峰家','白峰家','霞家','織部家','湖東家','赤城家','駿河井家','南海家','播磨井家','国人衆'].forEach((lord,i)=>{
    if(lord==='青葉家') return;
    S.ai[lord] = S.ai[lord] || {personality:PERSONALITIES[i%PERSONALITIES.length],aggression:45+(i%4)*12,risk:35+(i%5)*8,priority:'balanced',lastAction:'待機'};
  });
  S.ai['青葉家'] = S.ai['青葉家'] || {personality:'拡張型',aggression:50,risk:40,priority:'balanced',lastAction:'プレイヤー'};

  function inferTerrain(name){
    if(/越後|信濃|飛騨|甲斐|上野|紀伊|伊賀|丹波|但馬|美作|出雲|石見|肥後|薩摩/.test(name)) return '山地';
    if(/河内|摂津|播磨|備前|備中|備後|安芸|武蔵|相模|下総|上総|尾張|美濃|三河|駿河|遠江|筑前|筑後/.test(name)) return '平野';
    if(/越中|加賀|越前|近江|大和|伊勢|下野|常陸|陸奥|出羽|陸前|陸中|岩代|磐城/.test(name)) return '丘陵';
    return '海岸';
  }
  function initArmy(a){
    a.morale = a.morale ?? 78; a.fatigue=a.fatigue??0; a.supply=a.supply??100; a.training=a.training??55;
    a.commander=a.commander||S.retainers[Math.floor(Math.random()*Math.max(1,S.retainers.length))]?.[0]||'無名武将';
    a.unitType=a.unitType||'混成軍'; a.home=a.home||a.province; a.food=a.food??Math.max(100,a.troops*.8);
    a.actionPoints=a.actionPoints??2;
  }

  // ---------- ログ ----------
  function v9log(text,type='system'){
    const msg=`第${S.turn}ターン・${SEASONS[S.date.season]}：${text}`;
    S.log.unshift({turn:S.turn,text:msg,type}); S.log=S.log.slice(0,80);
    if(window.logBattle) window.logBattle(text);
  }

  // ---------- 季節・経済 ----------
  function advanceCalendar(){
    S.date.season=(S.date.season+1)%4;
    if(S.date.season===0) S.date.year++;
  }
  function updateEconomy(){
    let income=0,foodGain=0,pop=0;
    S.provinces.forEach(p=>{
      const growth = .006 + p.infrastructure*.00003 - p.unrest*.00008;
      p.population=Math.max(500,Math.round(p.population*(1+growth)));
      p.pop=p.population;
      const harvest = S.date.season===2 ? 1.22 : (S.date.season===1 ? 1.08 : .78);
      const food=Math.max(0,Math.round(p.koku*550*(.72+p.development/250)*harvest*(1-p.unrest/140)));
      const tax=Math.max(0,Math.round(p.koku*170*(.65+p.commerce/180)*p.taxRate));
      p.foodStock=Math.max(0,p.foodStock+food);
      p.goldStock=Math.max(0,p.goldStock+tax);
      if(p.lord==='青葉家'){income+=tax;foodGain+=food;pop+=p.population;}
      p.unrest=Math.max(0,p.unrest-(p.loyalty>60?2:1));
      p.loyalty=Math.max(0,Math.min(100,p.loyalty-(p.taxRate>.35?1:0)+ (p.unrest<10?1:0)));
    });
    S.gold += income; S.food += foodGain;
    S.population=pop || S.population;
    S.troops=S.armies.filter(a=>a.lord==='青葉家').reduce((n,a)=>n+a.troops,0);
  }
  function maintainArmies(){
    S.armies.forEach(a=>{
      initArmy(a);
      const consumption=Math.max(10,Math.round(a.troops*.12));
      const p=S.provinces.find(x=>x.id===a.province);
      const local=p?.lord===a.lord;
      if(local){a.supply=Math.min(100,a.supply+14);a.food+=consumption*.5;}
      else {a.food-=consumption;a.supply-=a.food<0?12:4;a.morale-=a.food<0?5:1;}
      a.fatigue=Math.min(100,a.fatigue+(a.status==='待機'?-6:5));
      a.supply=Math.max(0,a.supply);a.morale=Math.max(0,Math.min(100,a.morale));a.fatigue=Math.max(0,a.fatigue);
      if(a.supply<25){a.morale-=3;a.status=a.status==='待機'?'補給不足':a.status;}
      if(a.troops<=0)a.status='壊滅';
    });
  }

  // ---------- 戦闘 ----------
  function officer(a){return S.ai.officers?.[a.commander] || {leadership:55,martial:55,domestic:50,diplomacy:50};}
  function combatPower(a,p,defending=false){
    const o=officer(a), t=TERRAIN[p?.terrainType||'平野'];
    const terrain=defending?t.def:t.attack;
    const weather=S.weather==='雨'?.92:S.weather==='雪'?.86:1;
    const morale=.65+a.morale/180, supply=.55+a.supply/220, fatigue=1-a.fatigue*.003;
    return Math.max(1,a.troops*(.72+o.leadership/300+o.martial/400)*(a.training/100+.55)*morale*supply*fatigue*terrain*weather);
  }
  function detailedBattle(att,def,p){
    if(!att||!def||att.troops<=0||def.troops<=0)return;
    const ap=combatPower(att,p,false), dp=combatPower(def,p,true);
    const ratio=ap/(ap+dp);
    const variance=.88+Math.random()*.24;
    const aLoss=Math.max(1,Math.round(def.troops*(.07+.24*(1-ratio))*variance));
    const dLoss=Math.max(1,Math.round(att.troops*(.07+.24*ratio)*variance));
    att.troops=Math.max(0,att.troops-aLoss); def.troops=Math.max(0,def.troops-dLoss);
    att.morale+=ratio>.55?3:-5; def.morale+=ratio<.45?3:-5;
    att.fatigue+=8;def.fatigue+=7;
    const winner=ratio>.56?att:(ratio<.44?def:null);
    if(winner){const loser=winner===att?def:att;loser.status='敗走';winner.status='野戦勝利';}
    else {att.status='交戦';def.status='交戦';}
    v9log(`${p?.name||att.province}で${att.name}と${def.name}が交戦。損害 ${aLoss.toLocaleString()} / ${dLoss.toLocaleString()}。${winner?winner.name+'が優勢。':'決着せず。'}`,'battle');
  }

  // ---------- 城郭 ----------
  function getCastle(a,p,castle){
    const key=`${p.id}::${castle}`;
    if(!S.castleState[key]) S.castleState[key]={garrison:p.garrison||Math.round(p.koku*100),food:Math.round(p.koku*500),walls:Math.min(100,45+p.koku*.8),gate:80,inner:100,morale:72,sorties:0};
    return S.castleState[key];
  }
  function siegeTurn(){
    for(const s of [...(S.sieges||[])]){
      const a=S.armies.find(x=>x.id===s.armyId),p=S.provinces.find(x=>x.id===s.province);
      if(!a||!p)continue;
      const c=getCastle(a,p,s.castle);
      const o=officer(a);
      const mode=s.mode||'包囲';
      const pressure=Math.max(1,a.troops*(.004+o.martial/30000)*(a.supply/100));
      c.food=Math.max(0,c.food-Math.round(c.garrison*.018));
      c.morale=Math.max(0,c.morale-(c.food===0?5:1));
      if(mode==='兵糧攻め'){
        s.progress=Math.min(100,(s.progress||0)+Math.max(2,8-c.morale*.04));
      }else if(mode==='強攻'){
        c.walls=Math.max(0,c.walls-pressure*.025);c.gate=Math.max(0,c.gate-pressure*.05);
        c.garrison=Math.max(0,c.garrison-Math.round(pressure*.85));a.troops=Math.max(0,a.troops-Math.round(pressure*.32));
        s.progress=Math.min(100,(s.progress||0)+pressure*.055);
      }else{
        c.walls=Math.max(0,c.walls-pressure*.006);c.garrison=Math.max(0,c.garrison-Math.round(pressure*.24));
        s.progress=Math.min(100,(s.progress||0)+pressure*.025);
      }
      s.garrison=c.garrison;s.food=c.food;s.defense=c.walls;s.morale=c.morale;
      if(c.garrison<=0||c.morale<=10||s.progress>=100){
        const old=p.lord;p.lord=a.lord;p.color=a.lord==='青葉家'?'#7197b7':'#8d6f68';p.relation=a.lord==='青葉家'?'自領':'敵対';
        p.loyalty=48;p.unrest=18;c.garrison=Math.round(c.garrison*.2);S.sieges=S.sieges.filter(x=>x!==s);a.status='占領';a.target='';
        v9log(`${a.name}が${s.castle}を攻略。${p.name}国は${old}から${a.lord}へ。`,'battle');
      }
    }
  }

  // ---------- 補給線 ----------
  function supplyTurn(){
    S.armies.forEach(a=>{
      const home=S.provinces.find(p=>p.id===a.home), here=S.provinces.find(p=>p.id===a.province);
      if(!here)return;
      const distance=Math.max(0,Math.abs((home?.x||0)-here.x)+Math.abs((home?.y||0)-here.y))/100;
      const roadBonus=(window.roadLinks||[]).length?1.05:1;
      a.supply=Math.max(0,Math.min(100,a.supply + (here.lord===a.lord?10:0) - distance*2/roadBonus));
      if(a.supply<20)a.morale=Math.max(0,a.morale-4);
    });
  }

  // ---------- AI ----------
  function neighbors(p){
    const links=window.roadLinks||[];return links.flatMap(([a,b])=>a===p.id?[b]:b===p.id?[a]:[]).map(id=>S.provinces.find(x=>x.id===id)).filter(Boolean);
  }
  function aiAct(lord){
    const cfg=S.ai[lord];if(!cfg||lord==='青葉家')return;
    const own=S.provinces.filter(p=>p.lord===lord), enemy=S.provinces.filter(p=>p.lord!==lord);
    if(!own.length)return;
    const candidates=own.flatMap(p=>neighbors(p).filter(q=>q.lord!==lord).map(q=>({from:p,to:q,score:q.koku+(100-q.loyalty)*.4-(q.garrison||0)/150}))).sort((a,b)=>b.score-a.score);
    const attackChance=(cfg.aggression+(cfg.personality==='好戦型'?20:0)-(cfg.personality==='慎重型'?15:0))/100;
    if(candidates[0]&&Math.random()<attackChance){
      const c=candidates[0];let army=S.armies.find(a=>a.lord===lord&&a.province===c.from.id&&a.troops>1000&&a.status==='待機');
      if(!army){army={id:`ai_${lord}_${S.turn}_${Math.random().toString(36).slice(2,6)}`,lord,name:`${lord}方面軍`,troops:Math.min(7000,Math.max(2500,Math.round(c.from.koku*45))),province:c.from.id,status:'攻撃進軍',target:c.to.name,family:lord,home:c.from.id};initArmy(army);S.armies.push(army);}
      army.status='攻撃進軍';army.target=c.to.name;
      if(window.findRoute){const route=window.findRoute(c.from.id,c.to.id);if(route&&route.length>1)S.movements.push({armyId:army.id,route,index:0,remaining:route.length-1,type:'attack'});}
      cfg.lastAction=`${c.to.name}へ侵攻`;
      v9log(`${lord}（${cfg.personality}）が${c.to.name}への侵攻を開始。`,'ai');
    }else{
      const p=own.sort((a,b)=>a.development-b.development)[0];if(p){p.development=Math.min(100,p.development+2);p.infrastructure=Math.min(100,p.infrastructure+1);p.commerce=Math.min(100,p.commerce+1);cfg.lastAction=`${p.name}を内政強化`;}
    }
  }
  function runAI(){Object.keys(S.ai).filter(k=>k!=='officers').forEach(aiAct);}

  // ---------- 諜報 ----------
  function intelligenceReport(target){
    const enemy=S.armies.filter(a=>a.lord===target&&a.troops>0);
    const power=55+(S.retainers[0]?.[4]||50);
    const precision=Math.min(100,power);
    return enemy.map(a=>{
      const err=Math.round((100-precision)*.35);
      const min=Math.max(0,Math.round(a.troops*(1-err/100))),max=Math.round(a.troops*(1+err/100));
      return {name:a.name,province:a.province,status:a.status,min,max,precision};
    });
  }

  // ---------- 外交 ----------
  function relationScore(a,b){
    const r=S.relations.find(x=>(x[0]===a&&x[1]===b)||(x[0]===b&&x[1]===a));return r?r[3]:0;
  }
  function diplomaticTurn(){
    const lords=[...new Set(S.provinces.map(p=>p.lord))].filter(Boolean);
    for(const a of lords){for(const b of lords){if(a>=b)continue;const score=relationScore(a,b);if(Math.random()<.08){
      const r=S.relations.find(x=>(x[0]===a&&x[1]===b)||(x[0]===b&&x[1]===a));
      if(r){if(score<-40)r[2]='敵対';else if(score>60)r[2]='同盟';else if(score>25)r[2]='友好';else r[2]='中立';}
    }}}
  }

  // ---------- セーブ/ロード ----------
  const SAVE_KEY='sengoku_sim_v9_save';
  function serializableState(){
    const copy={};for(const k in S){if(k==='view')copy[k]=S[k];else copy[k]=S[k];}return copy;
  }
  window.v9Save=()=>{try{localStorage.setItem(SAVE_KEY,JSON.stringify(serializableState()));v9log('セーブデータを保存しました。');alert('v9のセーブデータを保存しました。');}catch(e){alert('保存に失敗しました。');}};
  window.v9Load=()=>{try{const raw=localStorage.getItem(SAVE_KEY);if(!raw){alert('セーブデータがありません。');return;}const data=JSON.parse(raw);Object.keys(S).forEach(k=>delete S[k]);Object.assign(S,data);location.reload();}catch(e){alert('ロードに失敗しました。');}};
  window.v9Export=()=>{const blob=new Blob([JSON.stringify(serializableState(),null,2)],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=`sengoku-v9-${S.turn}.json`;a.click();URL.revokeObjectURL(a.href);};

  // ---------- UI ----------
  function fmt(n){return Math.round(n||0).toLocaleString();}
  function renderV9Panels(){
    const domestic=document.getElementById('domesticContent');
    if(domestic){
      domestic.querySelectorAll('.v9-panel-extra').forEach(e=>e.remove());
      const el=document.createElement('div'); el.className='v9-panel-extra';
      el.innerHTML=`<h3>📈 v9経済・人口</h3><div class="v9-grid"><div class="card"><b>経済循環</b><br>人口 → 石高 → 税収・兵糧 → 動員力</div><div class="card"><b>季節</b><br>${S.date.year}年 ${SEASONS[S.date.season]} / 天候：${S.weather}</div></div><table><tr><th>国</th><th>人口</th><th>開発</th><th>商業</th><th>治安</th></tr>${S.provinces.filter(p=>p.lord==='青葉家').map(p=>`<tr><td>${p.name}</td><td>${fmt(p.population)}</td><td>${Math.round(p.development)}</td><td>${Math.round(p.commerce)}</td><td>${Math.round(100-p.unrest)}</td></tr>`).join('')}</table>`; domestic.appendChild(el);
    }
    const mil=document.getElementById('militaryContent');
    if(mil){
      mil.querySelectorAll('.v9-panel-extra').forEach(e=>e.remove());
      const el=document.createElement('div'); el.className='v9-panel-extra';
      el.innerHTML=`<h3>🚚 v9兵站・戦闘能力</h3><table><tr><th>部隊</th><th>兵力</th><th>士気</th><th>補給</th><th>疲労</th><th>練度</th><th>武将</th></tr>${S.armies.map(a=>`<tr><td>${a.name}</td><td>${fmt(a.troops)}</td><td>${Math.round(a.morale)}</td><td>${Math.round(a.supply)}%</td><td>${Math.round(a.fatigue)}</td><td>${Math.round(a.training)}</td><td>${a.commander}</td></tr>`).join('')}</table>`; mil.appendChild(el);
    }
    const dip=document.getElementById('diplomacyContent');
    if(dip){
      dip.querySelectorAll('.v9-panel-extra').forEach(e=>e.remove());
      const el=document.createElement('div'); el.className='v9-panel-extra';
      el.innerHTML=`<h3>🧠 v9 AI大名</h3><table><tr><th>勢力</th><th>性格</th><th>攻撃性</th><th>リスク</th><th>直近の判断</th></tr>${Object.keys(S.ai).filter(k=>k!=='officers').map(l=>{const c=S.ai[l];return `<tr><td>${l}</td><td>${c.personality}</td><td>${c.aggression}</td><td>${c.risk}</td><td>${c.lastAction}</td></tr>`}).join('')}</table>`; dip.appendChild(el);
    }
    const ret=document.getElementById('retainerContent');
    if(ret){
      ret.querySelectorAll('.v9-panel-extra').forEach(e=>e.remove());
      const el=document.createElement('div'); el.className='v9-panel-extra';
      el.innerHTML=`<h3>🧑‍✈️ v9武将状態</h3><div class="card">武将能力は戦闘・内政・外交・諜報の各判定に接続されています。</div>`; ret.appendChild(el);
    }
    const intel=document.getElementById('intelContent');
    if(intel){
      intel.querySelectorAll('.v9-panel-extra').forEach(e=>e.remove());
      const el=document.createElement('div'); el.className='v9-panel-extra';
      const lords=[...new Set(S.armies.map(a=>a.lord))].filter(x=>x!=='青葉家');
      el.innerHTML=`<h3>🕵️ v9諜報</h3><div class="card">敵軍情報は推定幅を持ち、諜報能力によって精度が変化します。</div>${lords.map(l=>`<h4>${l}</h4><table><tr><th>部隊</th><th>現在地</th><th>推定兵力</th><th>精度</th></tr>${intelligenceReport(l).map(x=>`<tr><td>${x.name}</td><td>${x.province}</td><td>${fmt(x.min)}～${fmt(x.max)}</td><td>${x.precision}%</td></tr>`).join('')}</table>`).join('')}`; intel.appendChild(el);
    }
  }
  function addV9Controls(){
    const side=document.querySelector('.side'); if(!side||document.getElementById('v9Save'))return;
    const hr=document.createElement('hr');side.appendChild(hr);
    [['v9Save','💾 セーブ'],['v9Load','📂 ロード'],['v9Export','📤 JSON出力']].forEach(([id,text])=>{const b=document.createElement('button');b.id=id;b.textContent=text;b.onclick=window[id];side.appendChild(b);});
    const badge=document.createElement('div');badge.className='v9badge';badge.textContent='v9 本格試作';side.appendChild(badge);
  }

  // ---------- ターン統合 ----------
  const next=document.getElementById('nextTurn');
  if(next){
    const baseNext=next.onclick;
    next.onclick=()=>{
      advanceCalendar();
      S.weather=['晴','晴','曇','雨','雪'][Math.floor(Math.random()*5)];
      updateEconomy(); maintainArmies(); supplyTurn(); runAI(); diplomaticTurn(); siegeTurn();
      if(typeof baseNext==='function') baseNext();
      S.troops=S.armies.filter(a=>a.lord==='青葉家').reduce((n,a)=>n+a.troops,0);
      document.getElementById('gold').textContent=fmt(S.gold);
      document.getElementById('food').textContent=fmt(S.food);
      document.getElementById('population').textContent=fmt(S.population);
      document.getElementById('troops').textContent=fmt(S.troops);
      document.getElementById('turn').textContent=`第${S.turn}ターン`;
      renderV9Panels();
      v9log('v9拡張処理：経済・AI・補給・外交・城郭を更新。');
    };
  }

  // 修正：既存ターン処理との二重加算を避けるため、上の統合処理ではv7の旧クリックを呼ばない。
  window.v9Battle=detailedBattle;
  window.v9SiegeTurn=siegeTurn;
  window.v9Intelligence=intelligenceReport;
  window.v9AI=runAI;
  window.v9Render=renderV9Panels;
  addV9Controls();
  renderV9Panels();
})();
